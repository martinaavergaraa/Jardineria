document.addEventListener("DOMContentLoaded", function() {
    alert("¡Bienvenido a Jardin Verde!");
});

document.addEventListener("DOMContentLoaded", function() {
    var mensajeBienvenida = "¡Bienvenido a Jardin Verde!";
    document.getElementById("mensaje-bienvenida").innerText = mensajeBienvenida;
});




